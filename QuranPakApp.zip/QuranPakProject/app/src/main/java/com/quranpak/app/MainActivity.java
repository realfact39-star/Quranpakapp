package com.quranpak.app;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.graphics.Bitmap;
import android.net.*;
import android.os.*;
import android.view.View;
import android.webkit.*;
import android.widget.*;
import androidx.activity.result.*;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.gms.ads.*;
import com.google.android.gms.ads.interstitial.*;
import com.google.android.gms.ads.rewarded.*;
@SuppressLint("SetJavaScriptEnabled")
public class MainActivity extends AppCompatActivity {
    private static final String HOME   = "file:///android_asset/index.html";
    // TEST IDs - replace with real IDs before publishing to Play Store
    private static final String BAN_ID = "ca-app-pub-3940256099942544/6300978111";
    private static final String INT_ID = "ca-app-pub-3940256099942544/1033173712";
    private static final String REW_ID = "ca-app-pub-3940256099942544/5224354917";
    private static final int    AD_N   = 5; // show interstitial every 5 pages
    private WebView mW; private ProgressBar mP; private SwipeRefreshLayout mS;
    private FrameLayout mBC; private View mOff; private AdView mBan;
    private InterstitialAd mInt; private RewardedAd mRew; private int mPg=0;
    private ValueCallback<Uri[]> mFC;
    private final ActivityResultLauncher<Intent> mFL = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(), r -> {
            if (mFC==null) return;
            Uri[] u=null;
            if (r.getResultCode()==Activity.RESULT_OK && r.getData()!=null) {
                Uri d=r.getData().getData(); if(d!=null) u=new Uri[]{d};
            }
            mFC.onReceiveValue(u); mFC=null;
        });
    private boolean mB1=false;
    private final Handler mBH=new Handler(Looper.getMainLooper());
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_main);
        mW=findViewById(R.id.webView); mP=findViewById(R.id.progressBar);
        mS=findViewById(R.id.swipeRefresh); mBC=findViewById(R.id.bannerAdContainer);
        mOff=findViewById(R.id.offlineView);
        initWeb(); initBanner(); loadInt(); loadRew(); initSwipe();
        View rv=findViewById(R.id.retryButton);
        if(rv!=null) rv.setOnClickListener(v->{if(ok()){off(false);mW.reload();}else Toast.makeText(this,"Still offline!",0).show();});
    }
    @SuppressLint("SetJavaScriptEnabled")
    private void initWeb() {
        WebSettings ws=mW.getSettings();
        ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true); ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        ws.setSupportZoom(true); ws.setBuiltInZoomControls(true); ws.setDisplayZoomControls(false);
        ws.setUseWideViewPort(true); ws.setLoadWithOverviewMode(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        ws.setAllowFileAccess(true); ws.setAllowContentAccess(true);
        mW.setLayerType(View.LAYER_TYPE_HARDWARE,null);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(mW,true);
        mW.addJavascriptInterface(new JSBridge(),"Android");
        mW.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v,String u,Bitmap b){mP.setVisibility(View.VISIBLE);mP.setProgress(0);}
            @Override public void onPageFinished(WebView v,String u){
                mP.setVisibility(View.GONE); mS.setRefreshing(false);
                CookieManager.getInstance().flush();
                if(++mPg % AD_N==0) showInt();}
            @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){
                if(r.isForMainFrame()){mP.setVisibility(View.GONE);mS.setRefreshing(false);if(!ok())off(true);}}
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){
                String u=r.getUrl().toString();
                if(u.startsWith("file://")||u.startsWith("about:")) return false;
                try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}
                catch(Exception ignored){}
                return true;}
        });
        mW.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v,int p){mP.setProgress(p);if(p==100)mP.setVisibility(View.GONE);}
            @Override public boolean onJsAlert(WebView v,String u,String m,JsResult r){
                new AlertDialog.Builder(MainActivity.this).setMessage(m).setPositiveButton("OK",(d,w)->r.confirm()).show();return true;}
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]>cb,FileChooserParams p){
                if(mFC!=null)mFC.onReceiveValue(null);mFC=cb;
                try{mFL.launch(p.createIntent());}catch(Exception e){mFC=null;return false;}return true;}
        });
        mW.setDownloadListener((url,ua,cd,mime,len)->{
            try{startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}
            catch(Exception e){Toast.makeText(this,"Cannot download",0).show();}});
        if(ok()) mW.loadUrl(HOME); else off(true);
    }
    private void initBanner(){
        mBan=new AdView(this); mBan.setAdUnitId(BAN_ID); mBan.setAdSize(AdSize.BANNER);
        mBC.addView(mBan); mBan.loadAd(new AdRequest.Builder().build());}
    private void loadInt(){
        InterstitialAd.load(this,INT_ID,new AdRequest.Builder().build(),new InterstitialAdLoadCallback(){
            @Override public void onAdLoaded(@NonNull InterstitialAd ad){mInt=ad;mInt.setFullScreenContentCallback(new FullScreenContentCallback(){
                @Override public void onAdDismissedFullScreenContent(){mInt=null;loadInt();}
                @Override public void onAdFailedToShowFullScreenContent(AdError e){mInt=null;loadInt();}});}
            @Override public void onAdFailedToLoad(@NonNull LoadAdError e){
                mInt=null; new Handler(Looper.getMainLooper()).postDelayed(()->loadInt(),30000);}});}
    public void showInt(){if(mInt!=null)mInt.show(this);}
    private void loadRew(){
        RewardedAd.load(this,REW_ID,new AdRequest.Builder().build(),new RewardedAdLoadCallback(){
            @Override public void onAdLoaded(@NonNull RewardedAd ad){mRew=ad;mRew.setFullScreenContentCallback(new FullScreenContentCallback(){
                @Override public void onAdDismissedFullScreenContent(){mRew=null;loadRew();}
                @Override public void onAdFailedToShowFullScreenContent(AdError e){mRew=null;loadRew();}});}
            @Override public void onAdFailedToLoad(@NonNull LoadAdError e){mRew=null;}});}
    public void showRew(){
        if(mRew!=null)mRew.show(this,item->{
            Toast.makeText(this,"JazakAllah! Reward earned.",0).show();
            mW.evaluateJavascript("if(typeof onRewardEarned==='function')onRewardEarned()",null);});
        else Toast.makeText(this,"Ad not ready...",0).show();}
    private void initSwipe(){mS.setColorSchemeResources(R.color.gold);mS.setOnRefreshListener(()->{if(ok()){off(false);mW.reload();}else{mS.setRefreshing(false);off(true);}});}
    private void off(boolean show){mOff.setVisibility(show?View.VISIBLE:View.GONE);mW.setVisibility(show?View.GONE:View.VISIBLE);}
    private boolean ok(){ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);if(cm==null)return false;
        NetworkCapabilities nc=cm.getNetworkCapabilities(cm.getActiveNetwork());
        return nc!=null&&(nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)||nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)||nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));}
    @Override public void onBackPressed(){
        if(mW.canGoBack()){mW.goBack();return;}
        if(mB1){super.onBackPressed();finish();return;}
        mB1=true; Toast.makeText(this,"Press back again to exit",0).show();
        mBH.postDelayed(()->mB1=false,2000);}
    @Override protected void onResume(){super.onResume();if(mBan!=null)mBan.resume();mW.onResume();}
    @Override protected void onPause(){super.onPause();if(mBan!=null)mBan.pause();mW.onPause();}
    @Override protected void onDestroy(){super.onDestroy();if(mBan!=null)mBan.destroy();if(mW!=null){mW.loadUrl("about:blank");mW.destroy();}mBH.removeCallbacksAndMessages(null);}
    public class JSBridge{
        @JavascriptInterface public void showAd(){runOnUiThread(()->showInt());}
        @JavascriptInterface public void showRewardedAd(){runOnUiThread(()->showRew());}
        @JavascriptInterface public void showToast(String m){runOnUiThread(()->Toast.makeText(MainActivity.this,m,0).show());}
        @JavascriptInterface public boolean isOnline(){return ok();}
        @JavascriptInterface public void share(String t,String u){runOnUiThread(()->{
            Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT,t+"
"+u);startActivity(Intent.createChooser(i,"Share"));});}
    }
}
