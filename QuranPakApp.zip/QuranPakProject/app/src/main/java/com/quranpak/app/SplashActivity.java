package com.quranpak.app;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.*;
import android.util.Log;
import android.view.WindowManager;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.ads.*;
import com.google.android.gms.ads.interstitial.*;
@SuppressLint("CustomSplashScreen")
public class SplashActivity extends AppCompatActivity {
    // TEST ID - replace with real ID before publishing
    private static final String AD_ID = "ca-app-pub-3940256099942544/1033173712";
    private InterstitialAd mAd;
    private boolean timerDone = false, adShown = false;
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        loadAd();
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            timerDone = true; tryGo();
        }, 2500);
    }
    private void loadAd() {
        InterstitialAd.load(this, AD_ID, new AdRequest.Builder().build(),
            new InterstitialAdLoadCallback() {
                @Override public void onAdLoaded(InterstitialAd ad) {
                    mAd = ad;
                    mAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                        @Override public void onAdDismissedFullScreenContent() { adShown=true; go(); }
                        @Override public void onAdFailedToShowFullScreenContent(AdError e) { go(); }
                    });
                    if (timerDone) tryGo();
                }
                @Override public void onAdFailedToLoad(LoadAdError e) {
                    mAd = null;
                    if (timerDone) go();
                }
            });
    }
    private void tryGo() { if (!timerDone) return; if (mAd!=null && !adShown) mAd.show(this); else go(); }
    private void go() {
        startActivity(new Intent(this, MainActivity.class));
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        finish();
    }
}
