package com.quranpak.app;
import android.app.Application;
import android.util.Log;
import com.google.android.gms.ads.MobileAds;
public class QuranPakApplication extends Application {
    @Override public void onCreate() {
        super.onCreate();
        MobileAds.initialize(this, s -> Log.d("QP","AdMob ready"));
    }
}
