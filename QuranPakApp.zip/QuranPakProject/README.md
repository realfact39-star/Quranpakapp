# QuranPak Android App

## How to get your APK:
1. Upload this ENTIRE folder to GitHub (new repository)
2. Go to Actions tab
3. Wait 5 minutes
4. Download QuranPak-APK
